#pragma once

#include <iostream>

namespace hw0
{

class Graph
{
public:
  Graph( uint32_t num_nodes )
  {
    /* TODO: Implement the constructor for the `Graph` class. */
  }

  ~Graph()
  {
    /* The destructor of the `Graph` class. */
  }

  void add_edge( uint32_t from, uint32_t to )
  {
    /* TODO: Add a new edge in your data structure. You can remove the following line. */
    std::cout << "[i] add edge from " << from << " to " << to << std::endl;
  }

  uint32_t num_degree_k( uint32_t k ) const
  {
    /* TODO: Count the number of nodes with degree `k`. */
    return 0;
  }

private:
  /* TODO: Define your data structure. Declare the data members of `Graph` here. 
           Feel free to define and implement other classes (e.g. `Node`) if you want. */

};

} // namespace hw0