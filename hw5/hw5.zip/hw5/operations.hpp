#pragma once

#include "BDD.hpp"

using index_t = typename BDD::index_t;
using var_t = typename BDD::var_t;

/* Compute ~f */
inline index_t BDD::NOT( index_t f )
{
  assert( f < nodes.size() && "Make sure f exists." );

  /* trivial cases */
  if ( f == constant( false ) )
  {
    return constant( true );
  }
  if ( f == constant( true ) )
  {
    return constant( false );
  }

  Node const& F = nodes[f];
  var_t x = F.v;
  index_t f0 = F.E, f1 = F.T;

  index_t const r0 = NOT( f0 );
  index_t const r1 = NOT( f1 );
  return unique( x, r1, r0 );
}

/* Compute f ^ g */
inline index_t BDD::XOR( index_t f, index_t g )
{
  assert( f < nodes.size() && "Make sure f exists." );
  assert( g < nodes.size() && "Make sure g exists." );

  /* trivial cases */
  if ( f == g )
  {
    return constant( false );
  }
  if ( f == constant( false ) )
  {
    return g;
  }
  if ( g == constant( false ) )
  {
    return f;
  }
  if ( f == constant( true ) )
  {
    return NOT( g );
  }
  if ( g == constant( true ) )
  {
    return NOT( f );
  }
  if ( f == NOT( g ) )
  {
    return constant( true );
  }

  Node const& F = nodes[f];
  Node const& G = nodes[g];
  var_t x;
  index_t f0, f1, g0, g1;
  if ( F.v < G.v ) /* F is on top of G */
  {
    x = F.v;
    f0 = F.E;
    f1 = F.T;
    g0 = g1 = g;
  }
  else if ( G.v < F.v ) /* G is on top of F */
  {
    x = G.v;
    f0 = f1 = f;
    g0 = G.E;
    g1 = G.T;
  }
  else /* F and G are at the same level */
  {
    x = F.v;
    f0 = F.E;
    f1 = F.T;
    g0 = G.E;
    g1 = G.T;
  }

  index_t const r0 = XOR( f0, g0 );
  index_t const r1 = XOR( f1, g1 );
  return unique( x, r1, r0 );
}

/* Compute f & g */
inline index_t BDD::AND( index_t f, index_t g )
{
  assert( f < nodes.size() && "Make sure f exists." );
  assert( g < nodes.size() && "Make sure g exists." );

  /* TODO (You should not, of course, return constant 0, so you will replace the following line.) */
  return constant( false );
}

/* Compute ITE(f, g, h), i.e., f ? g : h */
inline index_t BDD::ITE( index_t f, index_t g, index_t h )
{
  assert( f < nodes.size() && "Make sure f exists." );
  assert( g < nodes.size() && "Make sure g exists." );
  assert( h < nodes.size() && "Make sure h exists." );

  /* TODO (You should not, of course, return constant 0, so you will replace the following line.) */
  return constant( false );
}