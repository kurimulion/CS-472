#pragma once

#include "utils.hpp"
#include "truth_table.hpp"
#include "operators.hpp"

#include <cassert>

inline Truth_Table Truth_Table::positive_cofactor( uint8_t const var ) const
{
  assert( var < this->num_vars() );
  /* TODO */
  return Truth_Table( this->num_vars() );
}

inline Truth_Table Truth_Table::negative_cofactor( uint8_t const var ) const
{
  assert( var < this->num_vars() );
  Truth_Table result( this->num_vars() );
  /* TODO */
  return result;
}

inline Truth_Table Truth_Table::derivative( uint8_t const var ) const
{
  assert( var < this->num_vars() );
  Truth_Table result( this->num_vars() );
  /* TODO */
  return result;
}

inline Truth_Table Truth_Table::consensus( uint8_t const var ) const
{
  assert( var < this->num_vars() );
  Truth_Table result( this->num_vars() );
  /* TODO */
  return result;
}

inline Truth_Table Truth_Table::smoothing( uint8_t const var ) const
{
  assert( var < this->num_vars() );
  Truth_Table result( this->num_vars() );
  /* TODO */
  return result;
}